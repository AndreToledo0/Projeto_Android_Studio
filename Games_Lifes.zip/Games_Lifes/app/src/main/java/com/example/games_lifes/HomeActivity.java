package com.example.games_lifes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.Games_Lifes.MESSAGE";

    String checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        TextView textView5 = findViewById(R.id.textView5);
        String message1 = textView5.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message1);

        checkbox = intent.getStringExtra(FonteActivity.EXTRA_MESSAGE);

        EditText teste1 = findViewById(R.id.teste1);
        EditText teste2 = findViewById(R.id.teste2);
        EditText teste3 = findViewById(R.id.teste3);
        EditText teste4 = findViewById(R.id.teste4);
        EditText teste5 = findViewById(R.id.teste5);
        EditText teste6 = findViewById(R.id.teste6);


        if (checkbox == "checkIGN" ){

            teste1.setVisibility(View.INVISIBLE);
            teste2.setVisibility(View.INVISIBLE);
            teste3.setVisibility(View.INVISIBLE);

        }else if (checkbox == "checkVoxel"){

            teste4.setVisibility(View.INVISIBLE);
            teste5.setVisibility(View.INVISIBLE);
            teste6.setVisibility(View.INVISIBLE);
        }
    }

}
