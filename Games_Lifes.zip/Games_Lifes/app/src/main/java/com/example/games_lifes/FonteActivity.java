package com.example.games_lifes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class FonteActivity extends AppCompatActivity {

    String opcao;

    public static final String EXTRA_MESSAGE = "com.example.Games_Lifes.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fonte);

        Intent intent = getIntent();

        TextView textView2 = findViewById(R.id.textView2);
        CheckBox checkVoxel = findViewById(R.id.checkVoxel);
        CheckBox checkIGN = findViewById(R.id.checkIGN);
        Button button2 = findViewById(R.id.button2);

        String message1 = textView2.getText().toString();
        String message3 = checkVoxel.getText().toString();
        String message4 = checkIGN.getText().toString();
        String message5 = button2.getText().toString();

        intent.putExtra(EXTRA_MESSAGE, message1);
        intent.putExtra(EXTRA_MESSAGE, message3);
        intent.putExtra(EXTRA_MESSAGE, message4);
        intent.putExtra(EXTRA_MESSAGE, message5);
        intent.putExtra(EXTRA_MESSAGE, getopcaocheckbox());

    }


    public void Home(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    void setopcaocheckbox(String op){
        opcao = op;
    }

    String getopcaocheckbox(){
        return opcao;
    }

    class CheckBoxSelect implements View.OnClickListener {
        public void onClick(View view) {
            int id = view.getId();

            switch (id) {
                case R.id.checkVoxel:
                    setopcaocheckbox("checkVoxel");
                    break;

                case R.id.checkIGN:
                    setopcaocheckbox("checkIGN");
                    break;

            }

        }

    }
}